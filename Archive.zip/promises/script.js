console.log("=== Working with promises ===");
const ninjaPromise = new Promise((resolve, reject) => {
    resolve("Hattori");
    // reject("An error resolving a promise!")
});

ninjaPromise.then(ninja => {
    console.log(ninja === "Hattori", "We were promises Hattori.");
}, err => {
    fail("There shouldn`t be an error.");
});